# Abdul Sattar Jamali — Portfolio
Generated portfolio files including index.html, style.css, script.js.